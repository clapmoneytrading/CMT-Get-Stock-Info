const form = document.getElementById("lookup-form");
const statusEl = document.getElementById("status");
const recordsBody = document.getElementById("records-body");
const filterInput = document.getElementById("filter");
const filterRoe = document.getElementById("filter-roe");
const filterRs = document.getElementById("filter-rs");
const filterEpsRating = document.getElementById("filter-eps-rating");
const filterPrice = document.getElementById("filter-price");
const filterMaster = document.getElementById("filter-master");
const filterPe = document.getElementById("filter-pe");
const filterEpsStrength = document.getElementById("filter-eps-strength");
const filterPriceStrength = document.getElementById("filter-price-strength");
const filterLast4q = document.getElementById("filter-last4q");
const filterEpsPercent = document.getElementById("filter-eps-percent");
const filterChange = document.getElementById("filter-change");
const filterSales = document.getElementById("filter-sales");
const filterSalesChange = document.getElementById("filter-sales-change");
const sortSelect = document.getElementById("sort");
const orderSelect = document.getElementById("order");
const manualForm = document.getElementById("manual-form");
const manualStatus = document.getElementById("manual-status");
const manualQuery = document.getElementById("manual-query");
const manualStock = document.getElementById("manual-stock");
const refreshButton = document.getElementById("refresh-all");
const refreshStatus = document.getElementById("refresh-status");
const previewCard = document.getElementById("lookup-preview");
const previewBody = document.getElementById("preview-body");
const addToDbButton = document.getElementById("add-to-db");
const addStatus = document.getElementById("add-status");

let latestLookup = null;

async function fetchRecords() {
  const params = new URLSearchParams({
    q: filterInput.value.trim(),
    return_on_equity: filterRoe.value.trim(),
    rs_rating: filterRs.value.trim(),
    eps_rating: filterEpsRating.value.trim(),
    current_price: filterPrice.value.trim(),
    master_score: filterMaster.value.trim(),
    pe_ratio: filterPe.value.trim(),
    eps_strength: filterEpsStrength.value.trim(),
    price_strength: filterPriceStrength.value.trim(),
    last_4_quarterly_earnings_percent: filterLast4q.value.trim(),
    eps_percent: filterEpsPercent.value.trim(),
    change: filterChange.value.trim(),
    sales_cr: filterSales.value.trim(),
    sales_change_percent: filterSalesChange.value.trim(),
    sort: sortSelect.value,
    order: orderSelect.value
  });

  const response = await fetch(`/api/records?${params.toString()}`);
  const data = await response.json();
  renderRecords(data.records || []);
}

function renderRecords(records) {
  recordsBody.innerHTML = "";

  records.forEach((record) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${record.stock_name || record.query || "-"}</td>
      <td>${record.current_price || "-"}</td>
      <td>${record.eps_strength || "-"}</td>
      <td>${record.price_strength || "-"}</td>
      <td>${record.master_score || "-"}</td>
      <td>${record.pe_ratio || "-"}</td>
      <td>${record.return_on_equity || "-"}</td>
      <td>${record.rs_rating || "-"}</td>
      <td>${record.eps_rating || "-"}</td>
      <td>${record.last_4_quarterly_earnings_percent || "-"}</td>
      <td>${record.eps_percent || "-"}</td>
      <td>${record.change || "-"}</td>
      <td>${record.sales_cr || "-"}</td>
      <td>${record.sales_change_percent || "-"}</td>
      <td>${new Date(record.queried_at).toLocaleString()}</td>
    `;
    recordsBody.appendChild(row);
  });
}

async function handleLookup(event) {
  event.preventDefault();
  const input = document.getElementById("query");
  const query = input.value.trim();
  if (!query) {
    return;
  }

  statusEl.textContent = "Fetching stock details...";
  manualStatus.textContent = "";
  addStatus.textContent = "";

  try {
    const response = await fetch("/api/lookup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Lookup failed.");
    }

    latestLookup = data.record;
    renderPreview(latestLookup);
    statusEl.textContent = "Lookup complete. Review details below.";
    input.value = "";
  } catch (error) {
    statusEl.textContent = error.message;
    manualQuery.value = query;
    manualStock.value = query;
    manualStatus.textContent = "Not found. Add a manual record below.";
    latestLookup = null;
    renderPreview(null);
  }
}

function renderPreview(record) {
  previewBody.innerHTML = "";
  addToDbButton.disabled = !record;

  if (!record) {
    const empty = document.createElement("p");
    empty.className = "preview-empty";
    empty.textContent = "Search a stock to see details here.";
    previewBody.appendChild(empty);
    return;
  }

  const fields = [
    ["Stock", record.stock_name || record.query || "-"],
    ["Price", record.current_price || "-"],
    ["EPS Str.", record.eps_strength || "-"],
    ["Price Str.", record.price_strength || "-"],
    ["Master", record.master_score || "-"],
    ["P/E", record.pe_ratio || "-"],
    ["ROE", record.return_on_equity || "-"],
    ["RS", record.rs_rating || "-"],
    ["EPS", record.eps_rating || "-"],
    ["Last 4Q %", record.last_4_quarterly_earnings_percent || "-"],
    ["EPS %", record.eps_percent || "-"],
    ["Change", record.change || "-"],
    ["Sales (Cr)", record.sales_cr || "-"],
    ["%Chg", record.sales_change_percent || "-"]
  ];

  fields.forEach(([label, value]) => {
    const row = document.createElement("div");
    row.className = "preview-item";
    row.innerHTML = `<span>${label}</span><strong>${value}</strong>`;
    previewBody.appendChild(row);
  });
}

async function handleAddToDb() {
  if (!latestLookup) {
    return;
  }

  addStatus.textContent = "Saving to database...";

  try {
    const response = await fetch("/api/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(latestLookup)
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Save failed.");
    }

    addStatus.textContent = `Saved: ${data.record.stock_name || data.record.query}`;
    await fetchRecords();
  } catch (error) {
    addStatus.textContent = error.message;
  }
}

async function handleManual(event) {
  event.preventDefault();
  manualStatus.textContent = "Saving manual record...";

  const formData = new FormData(manualForm);
  const payload = Object.fromEntries(formData.entries());

  try {
    const response = await fetch("/api/manual", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Manual save failed.");
    }

    manualStatus.textContent = `Saved: ${data.record.stock_name}`;
    manualForm.reset();
    await fetchRecords();
  } catch (error) {
    manualStatus.textContent = error.message;
  }
}

async function handleRefreshAll() {
  refreshStatus.textContent = "Refreshing all stocks...";

  try {
    const response = await fetch("/api/admin/refresh", { method: "POST" });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Refresh failed.");
    }

    refreshStatus.textContent = `Updated ${data.success} of ${data.total}.`;
    await fetchRecords();
  } catch (error) {
    refreshStatus.textContent = error.message;
  }
}

form.addEventListener("submit", handleLookup);
manualForm.addEventListener("submit", handleManual);
filterInput.addEventListener("input", fetchRecords);
filterRoe.addEventListener("input", fetchRecords);
filterRs.addEventListener("input", fetchRecords);
filterEpsRating.addEventListener("input", fetchRecords);
filterPrice.addEventListener("input", fetchRecords);
filterMaster.addEventListener("input", fetchRecords);
filterPe.addEventListener("input", fetchRecords);
filterEpsStrength.addEventListener("input", fetchRecords);
filterPriceStrength.addEventListener("input", fetchRecords);
filterLast4q.addEventListener("input", fetchRecords);
filterEpsPercent.addEventListener("input", fetchRecords);
filterChange.addEventListener("input", fetchRecords);
filterSales.addEventListener("input", fetchRecords);
filterSalesChange.addEventListener("input", fetchRecords);
sortSelect.addEventListener("change", fetchRecords);
orderSelect.addEventListener("change", fetchRecords);
refreshButton.addEventListener("click", handleRefreshAll);
addToDbButton.addEventListener("click", handleAddToDb);

fetchRecords();
