const cheerio = require("cheerio");
const { fetch } = require("undici");

const BASE_URL = "https://www.marketsmithindia.com";
const SEARCH_PATHS = [
  (query) => `/search?query=${encodeURIComponent(query)}`,
  (query) => `/search?q=${encodeURIComponent(query)}`
];

const FIELD_LABELS = {
  stock_name: ["Stock", "Company", "Name"],
  current_price: ["Current Price", "Price"],
  eps_strength: ["EPS Strength", "EPS Strength %", "EPS Strength(%)"],
  price_strength: ["Price Strength", "Price Strength %", "Price Strength(%)"],
  master_score: ["Master Score"],
  pe_ratio: ["P/E Ratio", "PE Ratio", "P/E"],
  return_on_equity: ["Return on Equity", "ROE"],
  rs_rating: ["RS Rating", "Relative Strength Rating"],
  eps_rating: ["EPS Rating"],
  last_4_quarterly_earnings_percent: ["Last 4 Quarterly Earnings %", "Last 4 Quarterly Earnings(%)"],
  eps_percent: ["EPS %", "EPS (%)"],
  change: ["Change"],
  sales_cr: ["Sales (Cr)", "Sales(Cr)"],
  sales_change_percent: ["%Chg", "% Change", "Sales %Chg"]
};

async function lookupStock(query) {
  const searchHtml = await fetchSearchPage(query);
  const stockUrl = findStockUrl(searchHtml);
  if (!stockUrl) {
    throw new Error(
      "No stock link found on the search page. The site may require login or a different search URL."
    );
  }

  const stockHtml = await fetchHtml(stockUrl);
  const $ = cheerio.load(stockHtml);

  const result = { source_url: stockUrl };
  Object.entries(FIELD_LABELS).forEach(([key, labels]) => {
    result[key] = extractByLabels($, labels);
  });

  if (!result.stock_name) {
    const title = ($("title").text() || "").trim();
    result.stock_name = title || query;
  }

  return result;
}

async function fetchSearchPage(query) {
  for (const pathBuilder of SEARCH_PATHS) {
    const url = `${BASE_URL}${pathBuilder(query)}`;
    const html = await fetchHtml(url);
    if (html) {
      return html;
    }
  }

  const fallback = `${BASE_URL}/stocks/${encodeURIComponent(query)}`;
  return fetchHtml(fallback);
}

async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
      "Accept": "text/html,application/xhtml+xml"
    }
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch ${url} (${response.status})`);
  }

  return response.text();
}

function findStockUrl(html) {
  if (!html) {
    return null;
  }

  const $ = cheerio.load(html);
  const link = $("a[href*='/stock/'], a[href*='/stocks/']").first();
  if (!link.length) {
    return null;
  }

  const href = link.attr("href");
  if (!href) {
    return null;
  }

  if (href.startsWith("http")) {
    return href;
  }

  return `${BASE_URL}${href}`;
}

function extractByLabels($, labels) {
  for (const label of labels) {
    const value = extractLabelValue($, label);
    if (value) {
      return value;
    }
  }
  return null;
}

function extractLabelValue($, labelText) {
  const normalizedLabel = normalizeText(labelText);
  const rows = $("tr");

  for (const row of rows) {
    const cells = $(row).find("th, td");
    if (cells.length < 2) {
      continue;
    }

    const first = normalizeText($(cells[0]).text());
    if (first.includes(normalizedLabel)) {
      const value = $(cells[cells.length - 1]).text();
      return normalizeValue(value);
    }
  }

  const labelElement = $("*")
    .filter((_, el) => normalizeText($(el).text()) === normalizedLabel)
    .first();

  if (labelElement.length) {
    const siblingText = normalizeValue(
      labelElement.closest("div, li, p").find("span, strong").last().text()
    );
    return siblingText || null;
  }

  return null;
}

function normalizeText(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/\u00a0/g, " ")
    .trim()
    .toLowerCase();
}

function normalizeValue(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/\u00a0/g, " ")
    .trim();
}

module.exports = {
  lookupStock
};
